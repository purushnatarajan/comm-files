package com.test.definitions;

import com.utils.CheckRules;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;

public class MyStepdefs {
    Scenario scenario;

    @Before
    public void setUp(Scenario scenario) throws Exception {
        this.scenario = scenario;
        CheckRules.createAllList();
    }


    @Given("with available records check record length")
    public void withAvailableRecordsCheckRecordLength() {
        CheckRules.validateRecords();

    }

    @After
    public void tearDown(){
        scenario.log("execution completed");
    }
}
