package com.test.runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
 features = "src/test/resources/features",
glue= {"com.test.definitions"},
plugin = {"pretty", "html:target/cucumber-reports/testresult.html"},
        monochrome = true,
        dryRun = false)

public class BDDRunner extends AbstractTestNGCucumberTests {
}
