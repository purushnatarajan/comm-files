package com.utils;

import com.poiji.annotation.ExcelCellName;

public class RawData {
@ExcelCellName("ExitCaseId")
    private String exitCaseId;
    @ExcelCellName("FirstName")
    private String firstName;
    @ExcelCellName("MiddleName")
    private String middleName;
    @ExcelCellName("LastName")
    private String lastName;
    @ExcelCellName("CustomerType")
    private String customerType;
    @ExcelCellName("BusinessName")
    private String businessName;

    @Override
    public String toString(){
        return "RawData{" + "ExitCaseId='"+exitCaseId+'\''+",FirstName='"+firstName+'\''+"," +
                "MiddleName='"+middleName+'\''+",LastName='\"+lastName+'\\''+\"," +
                "CustomerType='\"+customerType+'\\''+\",BusinessName='"+businessName+"}\n";
    }

    public String getExitCaseId() {
        return exitCaseId;
    }

    public void setExitCaseId(String exitCaseId) {
        this.exitCaseId = exitCaseId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }
}

