package com.utils;

import com.poiji.annotation.ExcelCellName;

public class RulesInfo {
@ExcelCellName("RuleField")
    private String ruleField;
    @ExcelCellName("RuleValue")
    private String ruleValue;
    @ExcelCellName("RuleFunction")
    private String ruleFunction;
    @ExcelCellName("DerivedValue")
    private String derivedValue;

    @Override
    public String toString(){
        return "RuleInfo{" + "RuleField='"+ruleField+'\''+",RuleValue='"+ruleValue+'\''+",RuleFunction='"+ruleFunction+'\''+",DerivedValue='"+derivedValue+"}\n";
    }

    public String getRuleField(){
        return ruleField;
    }

    public void setRuleField(String ruleField) {
        this.ruleField = ruleField;
    }

    public String getRuleFunction() {
        return ruleFunction;
    }

    public void setRuleFunction(String ruleFunction) {
        this.ruleFunction = ruleFunction;
    }

    public String getRuleValue() {
        return ruleValue;
    }

    public void setRuleValue(String ruleValue) {
        this.ruleValue = ruleValue;
    }

    public String getDerivedValue() {
        return derivedValue;
    }

    public void setDerivedValue(String derivedValue) {
        this.derivedValue = derivedValue;
    }
}

