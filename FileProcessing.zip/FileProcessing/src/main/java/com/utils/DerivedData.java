package com.utils;

import com.poiji.annotation.ExcelCellName;

public class DerivedData {
@ExcelCellName("RecordId")
    private String recordId;
    @ExcelCellName("Name")
    private String name;
    @ExcelCellName("CustomerType")
    private String customerType;


    @Override
    public String toString(){
        return "DerivedData{" + "RecordId='"+recordId+'\''+",Name='"+name+'\''+",CustomerType='"+customerType+"}\n";
    }

    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }
}

