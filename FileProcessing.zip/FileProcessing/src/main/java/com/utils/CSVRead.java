package com.utils;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvException;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class CSVRead {
    public static void main(String[] tmp) throws IOException, CsvException {
        CSVReader csvReader = new CSVReader(new FileReader("src/main/resources/test.csv"));
        List<String[]> allRows = csvReader.readAll();
        allRows.remove(0);
        FileWriter fileWriter = new FileWriter("src/main/resources/test.csv");
        CSVWriter csvWriter = new CSVWriter(fileWriter);
        csvWriter.writeAll(allRows);
        csvWriter.close();
        CSVReader csvReader1 = new CSVReader(new FileReader("src/main/resources/test.csv"));
        List<String[]> allRows1 = csvReader1.readAll();
        for (String[] rows:allRows1
             ) {
            System.out.println(Arrays.toString(rows));
        }


    }
}
