package com.utils;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class CheckRules {
    public static List<RulesInfo> rulesInfoList ;
    public static List<RawData> rawDataList ;
    public static List<DerivedData> derivedDataList ;
//public static void main(String[] args) throws IOException {
    public static void createAllList() throws Exception{
    FileInputStream inputStream = new FileInputStream(new File("src/main/resources/ExcelData.xlsx"));
    Workbook book1 = new XSSFWorkbook(inputStream);
    rulesInfoList = getRuleInfo(book1.getSheet("Rules"));
    rawDataList = getRawData(book1.getSheet("RawData"));
    derivedDataList = getDerivedData(book1.getSheet("DerivedData"));





}

public static void validateRecords(){
    for (DerivedData listValue:derivedDataList) {
        String recordID = listValue.getRecordId();
        checkRecord(rulesInfoList,listValue,rawDataList);
    }
}

public static void checkRecord(List<RulesInfo> rulesInfoList,DerivedData listValue,List<RawData> rawDataList){

    List<RawData> filteredRawData = null;
    List<RulesInfo> checkRecordID = rulesInfoList.stream().
            filter(rule -> rule.getRuleField().equals("RecordId")).collect(Collectors.toList());
    String newrecordID = (listValue.getRecordId().length() > Integer.parseInt(checkRecordID.get(0).getRuleValue())) ?
            (StringUtils.left(listValue.getRecordId(),3)+StringUtils.right(listValue.getRecordId(),7)):
            listValue.getRecordId();
    filteredRawData  =  rawDataList.stream().
            filter(rule -> rule.getExitCaseId().equals(newrecordID)).collect(Collectors.toList());
//RecordID check
    if(checkRecordID.get(0).getRuleFunction().equals("CHECKLENGTH")){
        int recIdLen =listValue.getRecordId().length();
        if(listValue.getRecordId().length() < Integer.parseInt(checkRecordID.get(0).getRuleValue())){
            System.out.println("length is less than "+checkRecordID.get(0).getRuleValue());
            return;
        }
        else{
              if(!filteredRawData.isEmpty()){
                System.out.println("Exit Case id is matching: "+filteredRawData.get(0).getExitCaseId());
            }
        }
    }

    // check Name
    List<RulesInfo> checkName = rulesInfoList.stream().
            filter(rule -> rule.getRuleField().equals("CustomerType")).collect(Collectors.toList());
    if(listValue.getCustomerType().equals("Individual")){
        List<RulesInfo> checkIndividual = checkName.stream().
                filter(rule -> rule.getRuleValue().equals("Individual")).collect(Collectors.toList());
        if(checkIndividual.get(0).getRuleFunction().equals("CONCAT")){
            String checkNameCondition = checkIndividual.get(0).getDerivedValue();
            if(checkNameCondition.equals("LastNameMiddleNameFirstName")){
                String finalName = filteredRawData.get(0).getLastName()+" "+filteredRawData.get(0).getMiddleName()+" "+filteredRawData.get(0).getFirstName();
                if(finalName.equals(listValue.getName())){
                    System.out.println("Individual name matches");
                }
            }

        }
    }
    if(listValue.getCustomerType().equals("Business")){
        List<RulesInfo> checkBusiness = checkName.stream().
                filter(rule -> rule.getRuleValue().equals("Business")).collect(Collectors.toList());
        if(checkBusiness.get(0).getRuleFunction().equals("CHECKNAME")){
            String checkNameCondition = checkBusiness.get(0).getDerivedValue();
            if(checkNameCondition.equals("BusinessName")){

                if(filteredRawData.get(0).getBusinessName().equals(listValue.getName())){
                    System.out.println("Business name matches");
                }
            }

        }
    }
    if(listValue.getCustomerType().equals("Agency")){
        List<RulesInfo> checkAgency = checkName.stream().
                filter(rule -> rule.getRuleValue().equals("Agency")).collect(Collectors.toList());
        if(checkAgency.get(0).getRuleFunction().equals("CHECKNAME")){
            String checkNameCondition = checkAgency.get(0).getDerivedValue();
            if(checkNameCondition.equals("BusinessName")){
                if(filteredRawData.get(0).getBusinessName().equals(listValue.getName())){
                    System.out.println("Agency name matches");
                }
            }

        }
    }
}
    private static List<RulesInfo> getRuleInfo(Sheet ruleSheet) {
        List<RulesInfo> rulesInfoList = new ArrayList<RulesInfo>();
        DataFormatter dataFormatter = new DataFormatter();
        for (int i = 1; i<= ruleSheet.getLastRowNum(); i++){
            Row row = ruleSheet.getRow(i);
            RulesInfo rulesInfo = new RulesInfo();
            int firstCellNo = row.getFirstCellNum();
            rulesInfo.setRuleField(dataFormatter.formatCellValue(row.getCell(firstCellNo)));
            rulesInfo.setRuleValue(dataFormatter.formatCellValue(row.getCell(++firstCellNo)));
            rulesInfo.setRuleFunction(dataFormatter.formatCellValue(row.getCell(++firstCellNo)));
            rulesInfo.setDerivedValue(dataFormatter.formatCellValue(row.getCell(++firstCellNo)));

            rulesInfoList.add(rulesInfo);
        }
        return rulesInfoList;
    }

    private static List<RawData> getRawData(Sheet rawData) {
        List<RawData> rawDataList = new ArrayList<RawData>();
        DataFormatter dataFormatter = new DataFormatter();
        for (int i = 1; i<= rawData.getLastRowNum(); i++){
            Row row = rawData.getRow(i);
            RawData rawDataRow = new RawData();
            int firstCellNo = row.getFirstCellNum();
            rawDataRow.setExitCaseId(dataFormatter.formatCellValue(row.getCell(firstCellNo)));
            rawDataRow.setFirstName(dataFormatter.formatCellValue(row.getCell(++firstCellNo)));
            rawDataRow.setMiddleName(dataFormatter.formatCellValue(row.getCell(++firstCellNo)));
            rawDataRow.setLastName(dataFormatter.formatCellValue(row.getCell(++firstCellNo)));
            rawDataRow.setCustomerType(dataFormatter.formatCellValue(row.getCell(++firstCellNo)));
            rawDataRow.setBusinessName(dataFormatter.formatCellValue(row.getCell(++firstCellNo)));
            rawDataList.add(rawDataRow);
        }
        return rawDataList;
    }

    private static List<DerivedData> getDerivedData(Sheet derivedData) {
        List<DerivedData> derivedDataList = new ArrayList<DerivedData>();
        DataFormatter dataFormatter = new DataFormatter();
        for (int i = 1; i<= derivedData.getLastRowNum(); i++){
            Row row = derivedData.getRow(i);
            DerivedData derivedDataRow = new DerivedData();
            int firstCellNo = row.getFirstCellNum();
            derivedDataRow.setRecordId(dataFormatter.formatCellValue(row.getCell(firstCellNo)));
            derivedDataRow.setName(dataFormatter.formatCellValue(row.getCell(++firstCellNo)));
            derivedDataRow.setCustomerType(dataFormatter.formatCellValue(row.getCell(++firstCellNo)));
            derivedDataList.add(derivedDataRow);
        }
        return derivedDataList;
    }
}
